﻿ChronoType by Caveras - based on the original main text font used in the 
Chrono Trigger video game for the SNES (Square, 1995).

The font file in this archive was created by Caveras using FontStruct - 
the free, online font-building tool. This font has a homepage where this 
archive and other versions may be found: 
http://fontstruct.com/fontstructors/caveras

It is also distributed over Caveras' website: http://www.caveras.net

Try FontStruct at http://fontstruct.com - It’s easy and it’s fun.

NOTE FOR FLASH USERS: FontStruct fonts (FontStructions) are optimized for 
Flash. The font in this archive is a pixel font and best displayed at a 
font-size of 12 and multiples of this number.

FontStruct is sponsored by FontShop. Visit them at http://fontshop.com. 
FontShop is the original independent font retailer. We’ve been around since 
the dawn of digital type. Whether you need the right font or need to create 
the right font from scratch, let our 23 years of experience work for you.

FontStruct is copyright © 2015 Rob Meek

LEGAL NOTICE:
In using this font you must comply with the licensing terms described in the 
file “license.txt” included with this archive. If you redistribute the font 
file in this archive, it must be accompanied by all the other files from this 
archive, including this one.

Copyright © 2015 Caveras / Cliff Modes.